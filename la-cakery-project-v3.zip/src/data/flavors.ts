// Common flavor variants offered by La Cakery, grouped by item category.
// Used on the item detail page so customers can pick a flavor before being
// sent to the matching Uber Eats store.

export const CAKE_FLAVORS = [
  "Chantilly (Vanilla & Cream)",
  "Mango",
  "Rocher (Hazelnut Chocolate)",
  "Tuxedo (Vanilla & Chocolate)",
  "Black Forest",
  "Triple Chocolate",
  "Kinder",
  "Nutella",
  "Pistachio",
  "Lemon Raspberry",
  "Strawberry",
  "Turtles (Caramel Pecan)",
  "Oreo",
  "Fudge",
  "Coconut",
  "Carrot",
  "Birthday Party (Vanilla)",
  "Brownie",
  "Hazelnut",
  "Lemon",
  "Neapolitan",
  "Dulce de Leche",
  "Royal Strawberry",
  "White Chocolate Raspberry",
];

export const CUPCAKE_FLAVORS = [
  "Vanilla Buttercream",
  "Chocolate",
  "Red Velvet",
  "Strawberry",
  "Lemon",
  "Funfetti",
  "Oreo",
  "Nutella",
  "Pistachio",
  "Salted Caramel",
  "Birthday Cake",
  "Cookies & Cream",
];

export const CHEESECAKE_FLAVORS = [
  "New York Strawberry",
  "New York Cherry",
  "Red Velvet",
  "Caramel Brownie",
  "Oreo",
  "Tiramisu",
  "Apple Caramel",
  "Skor",
  "Peanut Butter Fudge",
  "Carrot Caramel",
  "Raspberry Greek Yogurt",
  "NY Turtles",
  "White Chocolate Brownie",
];

export const MACARON_FLAVORS = [
  "Vanilla",
  "Chocolate",
  "Pistachio",
  "Raspberry",
  "Lemon",
  "Salted Caramel",
  "Rose",
  "Coffee",
  "Hazelnut",
  "Strawberry",
  "Mango",
  "Coconut",
];

export const CANNOLI_FLAVORS = ["Classic Ricotta", "Chocolate Chip", "Pistachio", "Nutella"];

export const CROISSANT_FLAVORS = [
  "Plain Butter",
  "Belgian Chocolate",
  "Almond",
  "Custard",
  "Raspberry",
  "Pistachio",
];

export const DONUT_FLAVORS = [
  "Honey Glazed",
  "Chocolate Glazed",
  "Boston Cream",
  "Maple",
  "Apple Fritter",
  "Cinnamon Sugar",
  "Strawberry",
  "Vanilla Sprinkle",
];

export const BROWNIE_FLAVORS = [
  "Classic Chocolate",
  "Triple Chocolate",
  "Caramel Pretzel",
  "Turtles (Pecan & Caramel)",
  "Magic Bar",
  "Caramel Cloud",
  "Coconut Caramel",
];

export const TOPPER_OPTIONS = ["Gold", "Silver", "Rose Gold"];

export const SLICE_FLAVORS = [
  "Decadent Chocolate",
  "Carrot Cake",
  "Red Velvet",
  "Black Forest",
  "Rainbow",
  "Tuxedo",
  "Strawberry Shortcake",
];

// Map an item to its flavor list based on name keywords.
export function getFlavorsFor(itemName: string): { label: string; options: string[] } | null {
  const n = itemName.toLowerCase();

  if (n.includes("topper")) return { label: "Color", options: TOPPER_OPTIONS };
  if (n.includes("cupcake")) return { label: "Choose flavours", options: CUPCAKE_FLAVORS };
  if (n.includes("macaron")) return { label: "Choose flavours", options: MACARON_FLAVORS };
  if (n.includes("cannoli")) return { label: "Choose flavour", options: CANNOLI_FLAVORS };
  if (n.includes("croissant")) return { label: "Choose flavour", options: CROISSANT_FLAVORS };
  if (n.includes("donut") || n.includes("fritter")) return { label: "Choose flavour", options: DONUT_FLAVORS };
  if (n.includes("cheesecake")) return { label: "Choose flavour", options: CHEESECAKE_FLAVORS };
  if (n.includes("brownie") || n.includes("square")) return { label: "Choose flavour", options: BROWNIE_FLAVORS };
  if (n.includes("slice")) return { label: "Choose flavour", options: SLICE_FLAVORS };
  if (n.startsWith("supreme") || n.includes("cake")) return { label: "Choose cake flavour", options: CAKE_FLAVORS };

  return null;
}
