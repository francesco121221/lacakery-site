import { useEffect, useRef } from "react";
import { Instagram, ArrowUpRight } from "lucide-react";

type Props = {
  handle: string;
  label: string;
  postUrls: string[];
};

declare global {
  interface Window {
    instgrm?: { Embeds: { process: () => void } };
  }
}

const InstagramFeed = ({ handle, label, postUrls }: Props) => {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const SCRIPT_ID = "instagram-embed-script";
    const process = () => window.instgrm?.Embeds.process();

    if (!document.getElementById(SCRIPT_ID)) {
      const s = document.createElement("script");
      s.id = SCRIPT_ID;
      s.async = true;
      s.src = "https://www.instagram.com/embed.js";
      s.onload = process;
      document.body.appendChild(s);
    } else {
      process();
    }
  }, [postUrls]);

  return (
    <div className="mb-16">
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <Instagram className="h-5 w-5 text-pink" />
          <h3 className="font-serif text-2xl md:text-3xl">{label}</h3>
        </div>
        <a
          href={`https://www.instagram.com/${handle}`}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1 text-sm text-pink hover:underline"
        >
          @{handle} <ArrowUpRight className="h-4 w-4" />
        </a>
      </div>
      <div ref={ref} className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {postUrls.map((url) => (
          <blockquote
            key={url}
            className="instagram-media"
            data-instgrm-permalink={url}
            data-instgrm-version="14"
            style={{
              background: "#FFF",
              border: 0,
              margin: 0,
              maxWidth: "100%",
              minWidth: "auto",
              padding: 0,
              width: "100%",
            }}
          />
        ))}
      </div>
    </div>
  );
};

export default InstagramFeed;
