import { useRef, useState } from "react";
import { Link } from "react-router-dom";
import { Star, Flame, ChevronLeft, ChevronRight } from "lucide-react";
import { menu as londonMenu, featured as londonFeatured, type MenuItem, type MenuCategory } from "@/data/menu";
import { slugify } from "@/lib/slug";
import { cn } from "@/lib/utils";

type Props = {
  menu?: MenuCategory[];
  featured?: MenuItem[];
  id?: string;
  eyebrow?: string;
  title?: React.ReactNode;
  orderUrl?: string;
  location?: "london" | "cambridge";
};

const badgeLabel = (b?: MenuItem["badge"]) => {
  if (b === "top1") return "#1 Most liked";
  if (b === "top2") return "#2 Most liked";
  if (b === "top3") return "#3 Most liked";
  if (b === "popular") return "Popular";
  return null;
};

const ItemCard = ({ item, location }: { item: MenuItem; location: "london" | "cambridge" }) => {
  const label = badgeLabel(item.badge);
  return (
    <Link
      to={`/menu/${location}/${slugify(item.name)}`}
      aria-label={`View flavours and order ${item.name}`}
      className="group flex justify-between gap-4 py-5 border-b border-border/60 hover:border-pink transition-colors cursor-pointer"
    >
      <div className="min-w-0 flex-1">
        {label && (
          <div className="inline-flex items-center gap-1.5 text-[10px] uppercase tracking-[0.2em] text-pink mb-2">
            <Flame className="h-3 w-3" />
            {label}
          </div>
        )}
        <h4 className="font-serif text-xl leading-tight group-hover:text-pink transition-colors">
          {item.name}
        </h4>
        {item.desc && (
          <p className="text-sm text-muted-foreground mt-1 leading-relaxed">{item.desc}</p>
        )}
        {item.rating && (
          <div className="inline-flex items-center gap-1 mt-2 text-xs text-muted-foreground">
            <Star className="h-3 w-3 fill-pink text-pink" />
            {item.rating}
          </div>
        )}
        <div className="text-[10px] uppercase tracking-[0.2em] text-pink/0 group-hover:text-pink mt-1 transition-colors">
          Pick a flavour →
        </div>
      </div>
      <div className="font-serif text-xl text-foreground whitespace-nowrap">{item.price}</div>
    </Link>
  );
};

const MenuSection = ({
  menu = londonMenu,
  featured = londonFeatured,
  id = "menu-prices",
  eyebrow = "Full Menu & Prices",
  title,
  orderUrl = "https://www.ubereats.com",
  location = "london",
}: Props) => {
  const [active, setActive] = useState(menu[0].id);
  const activeCat = menu.find((c) => c.id === active) ?? menu[0];
  const tabsRef = useRef<HTMLDivElement>(null);

  const scrollTabs = (dir: "left" | "right") => {
    const el = tabsRef.current;
    if (!el) return;
    const amount = Math.max(160, el.clientWidth * 0.7);
    el.scrollBy({ left: dir === "left" ? -amount : amount, behavior: "smooth" });
  };

  return (
    <section id={id} className="py-24 lg:py-32 bg-background">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="text-xs uppercase tracking-[0.25em] text-pink mb-4">{eyebrow}</div>
          <h2 className="font-serif text-5xl md:text-7xl leading-none text-balance">
            {title ?? <>Every treat, <span className="italic">priced</span> & ready.</>}
          </h2>
        </div>

        {/* Featured */}
        <div className="mb-20">
          <h3 className="font-serif text-2xl md:text-3xl mb-6 flex items-center gap-3">
            <Flame className="h-5 w-5 text-pink" />
            Featured & Most Loved
          </h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-px bg-border rounded-sm overflow-hidden">
            {featured.map((item) => {
              const label = badgeLabel(item.badge);
              return (
              <Link
                  key={item.name}
                  to={`/menu/${location}/${slugify(item.name)}`}
                  className="bg-background p-6 hover:bg-pink-soft/40 transition-colors block"
                >
                  {label && (
                    <div className="text-[10px] uppercase tracking-[0.2em] text-pink mb-3 font-medium">
                      {label}
                    </div>
                  )}
                  <div className="font-serif text-lg leading-tight min-h-[3.5rem]">{item.name}</div>
                  <div className="mt-4 flex items-center justify-between">
                    <span className="font-serif text-2xl">{item.price}</span>
                    {item.rating && (
                      <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
                        <Star className="h-3 w-3 fill-pink text-pink" />
                        {item.rating}
                      </span>
                    )}
                  </div>
                </Link>
              );
            })}
          </div>
        </div>

        {/* Category tabs */}
        <div className="relative -mx-6 lg:mx-0 mb-8">
          <button
            type="button"
            onClick={() => scrollTabs("left")}
            aria-label="Scroll categories left"
            className="absolute left-1 top-1/2 -translate-y-1/2 z-10 h-9 w-9 rounded-full bg-background border border-foreground/20 shadow-sm flex items-center justify-center hover:border-pink hover:text-pink transition-colors -mt-2"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={() => scrollTabs("right")}
            aria-label="Scroll categories right"
            className="absolute right-1 top-1/2 -translate-y-1/2 z-10 h-9 w-9 rounded-full bg-background border border-foreground/20 shadow-sm flex items-center justify-center hover:border-pink hover:text-pink transition-colors -mt-2"
          >
            <ChevronRight className="h-4 w-4" />
          </button>
          <div
            ref={tabsRef}
            className="flex gap-2 overflow-x-auto pb-4 scrollbar-hide px-12 snap-x snap-mandatory scroll-px-12 scroll-smooth"
          >
            {menu.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActive(cat.id)}
                className={cn(
                  "shrink-0 snap-start px-5 py-2.5 text-sm rounded-full border transition-all whitespace-nowrap",
                  active === cat.id
                    ? "bg-primary text-primary-foreground border-primary"
                    : "border-foreground/20 hover:border-pink hover:text-pink"
                )}
              >
                {cat.name}
              </button>
            ))}
          </div>
        </div>

        {/* Active category */}
        <div className="grid md:grid-cols-2 gap-x-12">
          {activeCat.items.map((item) => (
            <ItemCard key={item.name} item={item} location={location} />
          ))}
        </div>

        <p className="text-center text-xs text-muted-foreground mt-12">
          Prices in CAD. Menu and availability may vary in store and on Uber Eats.
        </p>
      </div>
    </section>
  );
};

export default MenuSection;
