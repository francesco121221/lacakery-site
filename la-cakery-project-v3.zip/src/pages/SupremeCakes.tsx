import { Button } from "@/components/ui/button";
import { ArrowUpRight, ArrowLeft, Phone, Crown } from "lucide-react";
import { Link } from "react-router-dom";

const LocationCard = ({
  title,
  phone,
  tel,
  whatsapp,
  orderUrl,
}: {
  title: string;
  phone: string;
  tel: string;
  whatsapp: string;
  orderUrl: string;
}) => (
  <div className="bg-primary p-8 lg:p-10 rounded-sm">
    <div className="text-[10px] uppercase tracking-[0.25em] text-pink mb-3">{title}</div>
    <h3 className="font-serif text-4xl md:text-5xl text-balance leading-none">
      Supreme <span className="italic text-pink">Cakes</span>
    </h3>
    <p className="mt-5 text-pink-blush/80 leading-relaxed">
      Our top-tier showstoppers — multi-tiered, hand-decorated and made for the moments you'll remember forever. Vegan, gluten-free, keto and sugar-free options on request.
    </p>
    <div className="mt-6 flex items-center gap-2">
      <Phone className="h-4 w-4 text-pink" strokeWidth={1.5} />
      <a href={`tel:${tel}`} className="font-serif text-lg hover:text-pink transition-colors">{phone}</a>
    </div>
    <div className="mt-6 flex flex-wrap gap-3">
      <Button asChild size="lg" className="rounded-full bg-pink hover:bg-pink-deep text-white px-6 h-12">
        <a href={orderUrl} target="_blank" rel="noopener noreferrer">
          Order online <ArrowUpRight className="ml-1 h-4 w-4" />
        </a>
      </Button>
      <Button asChild size="lg" className="rounded-full bg-[#25D366] hover:bg-[#1ebe57] text-white px-6 h-12">
        <a
          href={`https://wa.me/${whatsapp}?text=Hi%20La%20Cakery%2C%20I%27d%20like%20to%20order%20a%20Supreme%20Cake`}
          target="_blank"
          rel="noopener noreferrer"
        >
          WhatsApp <ArrowUpRight className="ml-1 h-4 w-4" />
        </a>
      </Button>
    </div>
  </div>
);

const SupremeCakes = () => {
  const features = [
    { title: "Multi-tier designs", desc: "Two, three or more tiers built for weddings, milestones and grand celebrations." },
    { title: "Hand-decorated", desc: "Sugar flowers, fine piping and custom toppers crafted in-house by our pastry team." },
    { title: "Premium flavours", desc: "Choose from our full flavour library — including Mango, Tuxedo, Tiramisu, Chantilly and Limoncello." },
  ];

  return (
    <div className="min-h-screen bg-noir text-primary-foreground">
      <header className="fixed top-0 inset-x-0 z-50 backdrop-blur-md bg-background/70 border-b border-border/40">
        <nav className="max-w-7xl mx-auto px-6 lg:px-10 h-16 flex items-center justify-between">
          <Link to="/" className="font-serif text-2xl tracking-tight text-foreground">
            La Cakery<span className="text-pink">.</span>
          </Link>
          <Link to="/" className="text-sm inline-flex items-center gap-1 text-foreground hover:text-pink transition-colors">
            <ArrowLeft className="h-4 w-4" /> Back
          </Link>
        </nav>
      </header>

      <section className="pt-32 pb-16 px-6 lg:px-10">
        <div className="max-w-6xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-pink mb-4">
            <Crown className="h-4 w-4" strokeWidth={1.5} /> The signature collection
          </div>
          <h1 className="font-serif text-5xl md:text-7xl leading-none text-balance">
            Supreme <span className="italic text-pink">Cakes</span>
          </h1>
          <p className="mt-6 text-pink-blush/80 max-w-xl mx-auto leading-relaxed">
            Our most extraordinary creations — built for weddings, anniversaries and the celebrations you want to remember forever.
          </p>
        </div>
      </section>

      <section className="px-6 lg:px-10 pb-16">
        <div className="max-w-6xl mx-auto grid md:grid-cols-3 gap-6">
          {features.map((f) => (
            <div key={f.title} className="bg-primary/60 border border-white/10 rounded-sm p-8">
              <h3 className="font-serif text-2xl mb-3">{f.title}</h3>
              <p className="text-pink-blush/70 text-sm leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="px-6 lg:px-10 pb-24">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-10">
            <div className="text-xs uppercase tracking-[0.25em] text-pink mb-3">Order yours</div>
            <h2 className="font-serif text-4xl md:text-5xl text-balance">Pick your location</h2>
          </div>
          <div className="grid md:grid-cols-2 gap-6">
            <LocationCard
              title="London · Wonderland Rd"
              phone="(519) 668-6045"
              tel="5196686045"
              whatsapp="15196686045"
              orderUrl="https://lacakery-london.square.site/s/order"
            />
            <LocationCard
              title="Cambridge · Hespeler Rd"
              phone="(519) 267-8045"
              tel="5192678045"
              whatsapp="15192678045"
              orderUrl="https://lacakery-london.square.site/s/order"
            />
          </div>
        </div>
      </section>
    </div>
  );
};

export default SupremeCakes;
