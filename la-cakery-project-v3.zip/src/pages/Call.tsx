import { Link } from "react-router-dom";
import { ArrowLeft, Phone, MapPin, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";

const LOCATIONS = [
  {
    name: "La Cakery London",
    sub: "Wonderland Rd",
    phone: "519-668-6045",
    tel: "5196686045",
    address: "London, ON",
    hours: "Tue – Sun · 10 AM – 7 PM",
  },
  {
    name: "La Cakery Cambridge",
    sub: "Hespeler Rd",
    phone: "519-267-8045",
    tel: "5192678045",
    address: "580 Hespeler Road, Cambridge, ON",
    hours: "Tue – Sun · 10 AM – 7 PM",
  },
];

const Call = () => {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="fixed top-0 inset-x-0 z-50 backdrop-blur-md bg-background/70 border-b border-border/40">
        <nav className="max-w-7xl mx-auto px-6 lg:px-10 h-16 flex items-center justify-between">
          <Link to="/" className="font-serif text-2xl tracking-tight">
            La Cakery<span className="text-pink">.</span>
          </Link>
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-sm hover:text-pink transition-colors"
          >
            <ArrowLeft className="h-4 w-4" /> Back home
          </Link>
        </nav>
      </header>

      <main className="pt-28 pb-24 max-w-4xl mx-auto px-6 lg:px-10">
        <div className="text-xs uppercase tracking-[0.25em] text-pink mb-4">Get in touch</div>
        <h1 className="font-serif text-5xl md:text-7xl leading-none text-balance">
          Call <span className="italic text-pink">us</span> directly.
        </h1>
        <p className="mt-6 text-lg text-muted-foreground max-w-xl">
          Pick the location closest to you for custom orders, questions, or to check on availability.
        </p>

        <div className="mt-12 grid md:grid-cols-2 gap-6">
          {LOCATIONS.map((loc) => (
            <div
              key={loc.tel}
              className="border border-border/60 rounded-sm p-8 hover:border-pink transition-colors"
            >
              <div className="text-[10px] uppercase tracking-[0.25em] text-pink mb-3">
                {loc.sub}
              </div>
              <h2 className="font-serif text-3xl leading-tight">{loc.name}</h2>

              <div className="mt-6 space-y-3 text-sm text-muted-foreground">
                <div className="flex items-start gap-2">
                  <MapPin className="h-4 w-4 mt-0.5 text-pink shrink-0" strokeWidth={1.5} />
                  <span>{loc.address}</span>
                </div>
                <div className="flex items-start gap-2">
                  <Clock className="h-4 w-4 mt-0.5 text-pink shrink-0" strokeWidth={1.5} />
                  <span>{loc.hours}</span>
                </div>
              </div>

              <a
                href={`tel:${loc.tel}`}
                className="mt-6 flex items-center gap-2 font-serif text-2xl text-foreground hover:text-pink transition-colors"
              >
                <Phone className="h-5 w-5 text-pink" />
                {loc.phone}
              </a>

              <Button
                asChild
                size="lg"
                className="mt-6 w-full rounded-full bg-pink hover:bg-pink-deep text-white h-12"
              >
                <a href={`tel:${loc.tel}`} aria-label={`Call ${loc.name} at ${loc.phone}`}>
                  Call {loc.sub}
                </a>
              </Button>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
};

export default Call;
