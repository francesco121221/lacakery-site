import { Button } from "@/components/ui/button";
import { ArrowUpRight, ArrowLeft, Phone } from "lucide-react";
import { Link } from "react-router-dom";

const Section = ({ title, phone, tel, orderUrl }: { title: string; phone: string; tel: string; orderUrl: string }) => (
  <div className="bg-primary p-8 lg:p-10 rounded-sm">
    <div className="text-[10px] uppercase tracking-[0.25em] text-pink mb-3">{title}</div>
    <h3 className="font-serif text-4xl md:text-5xl text-balance leading-none">
      8<span className="text-pink">"</span> Cakes
    </h3>
    <p className="mt-5 text-pink-blush/80 leading-relaxed">
      Our signature 8" round cakes — perfect for 8–12 servings. Choose from Mango, Tuxedo, Black Forest, Tiramisu, Chantilly, Limoncello and more. Vegan, gluten-free, keto and sugar-free options available on request.
    </p>
    <div className="mt-6 flex items-center gap-2">
      <Phone className="h-4 w-4 text-pink" strokeWidth={1.5} />
      <a href={`tel:${tel}`} className="font-serif text-lg hover:text-pink transition-colors">{phone}</a>
    </div>
    <div className="mt-6 flex flex-wrap gap-3">
      <Button asChild size="lg" className="rounded-full bg-pink hover:bg-pink-deep text-white px-6 h-12">
        <a href={orderUrl} target="_blank" rel="noopener noreferrer">
          Order online <ArrowUpRight className="ml-1 h-4 w-4" />
        </a>
      </Button>
    </div>
  </div>
);

const EightInchCakes = () => {
  return (
    <div className="min-h-screen bg-noir text-primary-foreground">
      <header className="fixed top-0 inset-x-0 z-50 backdrop-blur-md bg-background/70 border-b border-border/40">
        <nav className="max-w-7xl mx-auto px-6 lg:px-10 h-16 flex items-center justify-between">
          <Link to="/" className="font-serif text-2xl tracking-tight text-foreground">
            La Cakery<span className="text-pink">.</span>
          </Link>
          <Link to="/" className="text-sm inline-flex items-center gap-1 text-foreground hover:text-pink transition-colors">
            <ArrowLeft className="h-4 w-4" /> Back
          </Link>
        </nav>
      </header>

      <section className="pt-32 pb-24 px-6 lg:px-10">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-14">
            <div className="text-xs uppercase tracking-[0.25em] text-pink mb-4">Signature size</div>
            <h1 className="font-serif text-5xl md:text-7xl leading-none text-balance">
              8<span className="italic text-pink">"</span> Cakes
            </h1>
            <p className="mt-6 text-pink-blush/80 max-w-xl mx-auto">
              Order our most popular size for pickup at either location.
            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-6">
            <Section
              title="London · Wonderland Rd"
              phone="(519) 668-6045"
              tel="5196686045"
              orderUrl="https://lacakery-london.square.site/s/order"
            />
            <Section
              title="Cambridge · Hespeler Rd"
              phone="(519) 267-8045"
              tel="5192678045"
              orderUrl="https://lacakery-london.square.site/s/order"
            />
          </div>
        </div>
      </section>
    </div>
  );
};

export default EightInchCakes;
