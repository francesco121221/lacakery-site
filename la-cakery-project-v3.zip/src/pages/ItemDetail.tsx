import { useMemo } from "react";
import { Link, useParams } from "react-router-dom";
import { ArrowLeft, ArrowUpRight, Star, Flame } from "lucide-react";
import { Button } from "@/components/ui/button";
import { menu as londonMenu } from "@/data/menu";
import { menuCambridge } from "@/data/menuCambridge";
import type { MenuItem, MenuCategory } from "@/data/menu";
import { slugify } from "@/lib/slug";

const LOCATIONS: Record<
  string,
  { label: string; menu: MenuCategory[]; orderUrl: string }
> = {
  london: {
    label: "London · Wonderland Rd",
    menu: londonMenu,
    orderUrl: "https://www.ubereats.com/ca/store/la-cakery-wonderland-rd",
  },
  cambridge: {
    label: "Cambridge · Hespeler Rd",
    menu: menuCambridge,
    orderUrl: "https://www.ubereats.com/ca/store/la-cakery-cambridge",
  },
};

const findItem = (
  menu: MenuCategory[],
  slug: string,
): { item: MenuItem; category: MenuCategory } | null => {
  for (const cat of menu) {
    const found = cat.items.find((i) => slugify(i.name) === slug);
    if (found) return { item: found, category: cat };
  }
  return null;
};

const ItemDetail = () => {
  const { location = "london", slug = "" } = useParams();
  const loc = LOCATIONS[location] ?? LOCATIONS.london;
  const result = useMemo(() => findItem(loc.menu, slug), [loc, slug]);

  if (!result) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center px-6">
        <div className="text-center">
          <h1 className="font-serif text-4xl mb-4">Treat not found</h1>
          <Button asChild className="rounded-full">
            <Link to="/">Back to menu</Link>
          </Button>
        </div>
      </div>
    );
  }

  const { item, category } = result;

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="fixed top-0 inset-x-0 z-50 backdrop-blur-md bg-background/70 border-b border-border/40">
        <nav className="max-w-7xl mx-auto px-6 lg:px-10 h-16 flex items-center justify-between">
          <Link to="/" className="font-serif text-2xl tracking-tight">
            La Cakery<span className="text-pink">.</span>
          </Link>
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-sm hover:text-pink transition-colors"
          >
            <ArrowLeft className="h-4 w-4" /> Back to menu
          </Link>
        </nav>
      </header>

      <main className="pt-28 pb-24 max-w-3xl mx-auto px-6 lg:px-10">
        <div className="text-xs uppercase tracking-[0.25em] text-pink mb-4">
          {loc.label} · {category.name}
        </div>
        <h1 className="font-serif text-5xl md:text-6xl leading-none text-balance">
          {item.name}
        </h1>

        <div className="mt-6 flex items-center gap-4 flex-wrap">
          <span className="font-serif text-3xl">{item.price}</span>
          {item.rating && (
            <span className="inline-flex items-center gap-1 text-sm text-muted-foreground">
              <Star className="h-4 w-4 fill-pink text-pink" />
              {item.rating}
            </span>
          )}
          {item.badge && (
            <span className="inline-flex items-center gap-1.5 text-[10px] uppercase tracking-[0.2em] text-pink">
              <Flame className="h-3 w-3" />
              Most loved
            </span>
          )}
        </div>

        {item.desc && (
          <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
            {item.desc}
          </p>
        )}

        <div className="mt-12 border-t border-border/60 pt-10">
          <p className="text-sm text-muted-foreground">
            Confirm to head over to Uber Eats — pick your flavour and any extras there before checking out.
          </p>

          <div className="mt-8 flex flex-wrap gap-3">
            <Button
              asChild
              size="lg"
              className="rounded-full bg-pink hover:bg-pink-deep text-white px-8 h-12"
            >
              <a
                href={loc.orderUrl}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={`Confirm and order ${item.name} on Uber Eats`}
              >
                Confirm &amp; order on Uber Eats
                <ArrowUpRight className="ml-1 h-4 w-4" />
              </a>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="rounded-full border-foreground/20 px-8 h-12"
            >
              <Link to="/">Back to menu</Link>
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
};

export default ItemDetail;
